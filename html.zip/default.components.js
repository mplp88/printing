let Index = Vue.component('index', {
  template: ''+
    '<div>'+
    '  <h1>{{ title }}</h1>'+
    '</div>',
  data: function() {
    return {
      title: 'Index'
    }
  }
});

let About = Vue.component('about', {
  template: ''+
    '<div>'+
    '  <h1>{{ title }}</h1>'+
    '</div>',
  data: function() {
    return {
      title: 'About'
    }
  }
});

let Contact = Vue.component('contact', {
  template: ''+
    '<div>'+
    '  <h1>{{ title }}</h1>'+
    '  <form @sutbmit.prevent class="needs-validation" novalidate>'+
    '    <div class="form-row form-group">'+
    '      <label for="name">Nombre</label>'+
    '      <input class="form-control" type="text" id="name" name="name" placeholder="Nombre" required>'+
    '      <div class="valid-feedback">todo bien</div>'+
    '      <div class="invalid-feedback">Debe tener un valor</div>'+
    '    </div>'+
    '    <input class="btn btn-primary" type="submit" value="submit"/>'+
    '  </form>'+
    '</div>',
  data: function() {
    return {
      title: 'Contact'
    }
  }
});

let NavBar = Vue.component('navbar', {
  template: ''+
    '<nav class="navbar navbar-expand navbar-dark bg-dark">'+
    '  <router-link class="navbar-brand" to="/">Site</router-link>'+
    '  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">'+
    '    <span class="navbar-toggler-icon"></span>'+
    '  </button>'+
    '  <div v-if="routes.length" class="collapse navbar-collapse" id="navbarSupportedContent">'+
    '    <ul class="navbar-nav mr-auto">'+
    '      <li class="nav-item" v-for="route in routes">'+
    '        <router-link class="nav-link" :to="route.path">{{ route.name }}</router-link>'+
    '      </li>'+
    '    </ul>'+
    '  </div>'+
    '  <div v-else >'+
    '    <ul class="navbar-nav mr-auto">'+
    '      <li class="nav-item">'+
    '        <a href="#" class="nav-link" @click.prevent>Loading... <i class="fas fa-sync fa-spin"></i></a>'+
    '      </li>'+
    '    </ul>'+
    '  </div>'+
    '</nav>',
    data: function() {
      return {
        routes: []
      }
    },
    mounted: function() {
      let vm = this;
      vm.$router.options.routes.forEach(route => {
        vm.routes.push({
          name: route.name,
          path: route.path
        })
      });
    }
})