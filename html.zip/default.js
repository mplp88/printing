
(function() {
  'use strict';
  window.addEventListener('load', function() {
    let forms = document.getElementsByClassName('need-validation');
    let validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(evt) {
        if(form.checkValidity() === false) {
          evt.preventDefault();
          evt.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false)
    })
  }, false)
})();

let app = new Vue({
  el: '#app',
  router,
  template: ''+
    '<div>'+
    '  <navbar></navbar>'+
    '  <router-view class="container"></router-view>'+
    '</div>',
  data: function() {
    return {
      hello: 'Hello, World!'
    }
  }
})