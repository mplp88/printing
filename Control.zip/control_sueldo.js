const EmpresaTarjeta = {
  visa: 0,
  master: 1,
  amex: 2
}

const TiposTarjeta = {
  debito: 0,
  credito: 1
}

function generateGuid() {
  return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c => (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16));
}

class Gasto {
  constructor(concepto, valor, fecha, moneda) {
    this.id = generateGuid();
    this.concepto = concepto;
    this.valor = valor;
    this.fecha = convertirFecha(fecha);
  }
  
  convertirFecha(fecha) {
    return new Date(fecha);
  }
}

class GastoConTarjeta extends Gasto{
  constructor(concepto, valor, fecha, moneda, cantidadCuotas) {
    super(concepto, valor, fecha, moneda);
    this.cantidadCuotas = cantidadCuotas ? cantidadCuotas : 1;
    this.valorCuota = this.calcularValorCuota();
  }
  
  calcularValorCuota() {
    let valor = this.valor;
    if(this.tipo == TiposTarjeta.credito) {
      valor = this.valor / this.cantidadCuotas;
    }
    return valor;
  }
}

class Tarjeta {
  constructor(descripcion, empresa, entidad, tipo, numero) {
    this.id = generateGuid();
    this.descripcion = descripcion ? descripcion : empresa + ' ' + entidad + ' (' + tipo +')';
    this.empresa = empresa;
    this.entidad = entidad;
    this.tipo = tipo;
    this.numero = numero;
    this.gastos = [];
  }
  
  addGasto(concepto, valor, fecha, moneda, cantidadCuotas) {
    let gasto = new GastoConTarjeta(concepto, valor, fecha, moneda, cantidadCuotas);
    this.gastos.push(gasto)
  }
}

class Persona {
  constructor(nombre, apellido) {
    this.id = generateGuid();
    this.nombre = nombre;
    this.apellido = apellido;
    this.tarjetas = [];
    this.gastos = [];
  }
  
  addGasto(concepto, valor, fecha) {
    let gasto = new Gasto(concepto, valor, fecha);
    this.gastos.push(gasto);
  }
  
  addTarjeta(empresa, entidad, tipo, numero) {
    let tarjeta = new Tarjeta(empresa, entidad, tipo, numero);
    this.tarjetas.push(tarjeta);
  }
}

const p = new Persona('Pepe', 'García');
p.addTarjeta(null, 'Visa', 'Galicia', TiposTarjeta.debito, '1234 5678 9012 1234')
p.addTarjeta(null, 'Visa', 'Galicia', TiposTarjeta.credito, '1234 5678 9012 1235')
p.addTarjeta(null, 'Mastercard', 'Galicia', TiposTarjeta.credito, '1234 5678 9012 1236')

document.body.innerHTML = JSON.stringify(p);
